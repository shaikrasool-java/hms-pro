package com.nareshit.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class SuperAdmin extends User implements Serializable {

	@OneToMany
	private List<Hospital> hospitals;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="sid")
	private Integer id;

	//setters and getters
	
	public List<Hospital> getHospitals() {
		return hospitals;
	}
	public void setHospitals(List<Hospital> hospitals) {
		this.hospitals = hospitals;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	
	
	//default constructor
	public SuperAdmin() {
		super();
	}
	//parameterized constructor
	public SuperAdmin(List<Hospital> hospitals, Integer id) {
		super();
		this.hospitals = hospitals;
		this.id = id;
	}
	
	
	
	//toString method
	@Override
	public String toString() {
		return "SuperAdmin [hospitals=" + hospitals + ", id=" + id + "]";
	}
	
	
}
