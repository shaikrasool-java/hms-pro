package com.nareshit.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="htable")
public class Hospital {
	@ManyToOne
	private SuperAdmin sadmin;

	@OneToOne
	private Admin admin;
	
	@Id
	@Column(name="hid")
	@GeneratedValue
	private Integer id;
	
	@Column(name="hospitalname", unique=true)
	private String hname;
	@Column(name="address1")
	private String addr1;
	@Column(name="address2")
	private String addr2;
	@Column(name="hcity")
	private String city;
	@Column(name="hstate")
	private String state;
	@Column(name="hcountry")
	private String country;
	@Column(name="hzip")
	private Integer zip;
	@Column(name="hemail", nullable=false,unique=true)
	private String email;
	@Column(name="hfax")
	private String fax;
	@Column(name="hstatus")
	private boolean status;
	
	//default constructor
	public Hospital() {
		super();
	}
	//parameterized constructor

	public Hospital(Integer id, String hname, String addr1, String addr2, String city, String state, String country,
			Integer zip, String email, String fax, boolean status) {
		super();
		this.id = id;
		this.hname = hname;
		this.addr1 = addr1;
		this.addr2 = addr2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.email = email;
		this.fax = fax;
		this.status = status;
	}
	//setter methods and getter methods

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getZip() {
		return zip;
	}

	public void setZip(Integer zip) {
		this.zip = zip;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	// to String method
	@Override
	public String toString() {
		return "Hospital [id=" + id + ", hname=" + hname + ", addr1=" + addr1 + ", addr2=" + addr2 + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", zip=" + zip + ", email=" + email + ", fax=" + fax
				+ ", status=" + status + "]";
	}
	
	

	
	
}