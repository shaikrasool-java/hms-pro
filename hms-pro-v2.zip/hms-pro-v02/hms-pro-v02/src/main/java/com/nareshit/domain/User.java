package com.nareshit.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="uid")
	private Integer id;
	@Column(name="firstname")
	private String fname;
	@Column(name="lastname")
	private String lname;
	@Column(name="email")
	private String email;
	@Column(name="contact")
	private Long mobile;
	@Column(name="pwd")
	private String password;
	@Column(name="cpwd")
	private String conpassword;
	@Column(name="status")
	private boolean status;
}
