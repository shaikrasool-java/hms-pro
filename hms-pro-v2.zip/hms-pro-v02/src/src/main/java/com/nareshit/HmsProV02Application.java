package com.nareshit;

import javax.persistence.EntityManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.vendor.HibernateJpaSessionFactoryBean;

@SpringBootApplication
public class HmsProV02Application {

	public static void main(String[] args) {
		SpringApplication.run(HmsProV02Application.class, args);
	}
	
/*	@Bean
	public InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver views = new InternalResourceViewResolver();
		views.setPrefix("/WEB-INF/views/");
		views.setSuffix(".jsp");
		return views;
		
	}*/
	
	@Bean
	public HibernateJpaSessionFactoryBean sessionfactory() {
		
		return new HibernateJpaSessionFactoryBean();
	}
	
	
	
}
