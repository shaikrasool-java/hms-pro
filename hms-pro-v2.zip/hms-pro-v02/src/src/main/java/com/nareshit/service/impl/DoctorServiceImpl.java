package com.nareshit.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nareshit.bean.DoctorBean;
import com.nareshit.dao.IDoctorDao;
import com.nareshit.domain.Address;
import com.nareshit.domain.Doctor;
import com.nareshit.service.IDoctorService;
import com.nareshit.utility.DoctorMapper;

@Service
public class DoctorServiceImpl implements IDoctorService {

	@Autowired
	private IDoctorDao doctorDao;
	
	/*@Override
	public DoctorBean saveDoctor(DoctorBean doctorBean) {
		
		Doctor dr=DoctorMapper.mapBeanToDomain(doctorBean);
		dr=doctorDao.addDocotor(dr);
		doctorBean= DoctorMapper.mapDomainToBean(dr);
		return doctorBean;
		
	}
	*/
	
	@Override
	public DoctorBean saveDoctor(Doctor dr) {
		Doctor d=doctorDao.addDocotor(dr);
		return DoctorMapper.mapDomainToBean(d);
	}
	

	@Override
	public void deleteDoctor(int id) {

		doctorDao.deleteDoctor(id);
	}

	@Override
	public DoctorBean updateDoctor(DoctorBean doctorBean) {

		Doctor dr=DoctorMapper.mapBeanToDomain(doctorBean);
		dr=doctorDao.updateDoctor(dr);
		doctorBean=DoctorMapper.mapDomainToBean(dr);
		
		return doctorBean;
	}
	@Override
	public DoctorBean getDoctorById(int id) {

		Doctor dr=doctorDao.getOneDoctor(id);
		DoctorBean doctorBean=DoctorMapper.mapDomainToBean(dr);
		
		return doctorBean;
	}


	@Override
	public List<DoctorBean> getAllDoctors() {
		List<Doctor> drList = doctorDao.getAllDoctors();
		List<DoctorBean> doctBeanList = DoctorMapper.mapDomainListToBean(drList.iterator());
		return doctBeanList;
	}





@Override
public List<Doctor> findDoctorByName(String lowerCase) {
	// TODO Auto-generated method stub
	return null;
}


@Override
public List<DoctorBean> searchDoctor(String name, String serachValue) {
	String criteria = "";
	if (serachValue.equals("Name")) {
		criteria = criteria + "fname";
	} else {
		criteria = criteria + "email";
	}
	List<Doctor> doctList = doctorDao.searchDoctor(name, criteria);

	List<DoctorBean> doctBeanList = DoctorMapper.mapDomainListToBean(doctList.iterator());
	return doctBeanList;
}



}
