package com.nareshit.bean;

import java.io.Serializable;

public class PatientBean extends UserBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
